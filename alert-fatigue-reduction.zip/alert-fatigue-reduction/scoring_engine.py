"""
scoring_engine.py
------------------
Core logic that scores each raw alert 0-100 based on:
    1. Base severity of the alert type
    2. Criticality of the asset involved
    3. Whether the source is a known "chronic noise" source
       (i.e. historically high false-positive rate)
    4. Time-of-day anomaly (activity outside business hours is riskier)

This is intentionally implemented as transparent, explainable weighted
logic rather than a black-box ML model -- in a real SOC, analysts and
auditors need to be able to explain *why* an alert got the score it did.
"""

import pandas as pd

SEVERITY_SCORE = {"low": 10, "medium": 30, "high": 55, "critical": 80}

# Weights - tune these based on your environment / risk appetite
WEIGHT_SEVERITY = 0.45
WEIGHT_ASSET = 0.25
WEIGHT_TIME = 0.10
NOISE_PENALTY = 0.55  # multiplicative penalty for known chronic-noise sources


def business_hours_penalty(ts: pd.Timestamp) -> int:
    """Return an anomaly score (0-100) based on time of day.
    Activity at night / weekends is more suspicious."""
    hour = ts.hour
    is_weekend = ts.weekday() >= 5
    if is_weekend:
        return 90
    if hour < 6 or hour >= 22:
        return 80
    if hour < 8 or hour > 18:
        return 40
    return 10


def score_alerts(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])

    df["severity_score"] = df["base_severity"].map(SEVERITY_SCORE).fillna(10)
    df["asset_score"] = df["asset_criticality"] * 20  # 1-5 -> 20-100
    df["time_anomaly_score"] = df["timestamp"].apply(business_hours_penalty)

    raw_score = (
        df["severity_score"] * WEIGHT_SEVERITY
        + df["asset_score"] * WEIGHT_ASSET
        + df["time_anomaly_score"] * WEIGHT_TIME
    )

    # Chronic noise sources get their score dampened - this is the single
    # biggest lever for cutting alert fatigue, since a small number of
    # noisy scanners/services typically account for a large share of
    # daily alert volume.
    noise_multiplier = df["is_chronic_noise_source"].apply(
        lambda x: NOISE_PENALTY if x else 1.0
    )

    df["risk_score"] = (raw_score * noise_multiplier).round(1).clip(0, 100)

    df["priority"] = pd.cut(
        df["risk_score"],
        bins=[-1, 25, 50, 75, 100],
        labels=["Info", "Low", "Medium", "High"],
    )

    return df


if __name__ == "__main__":
    df = pd.read_csv("data/raw_alerts.csv")
    scored = score_alerts(df)
    scored.to_csv("data/scored_alerts.csv", index=False)
    print(scored[["alert_name", "risk_score", "priority"]].head(10))
