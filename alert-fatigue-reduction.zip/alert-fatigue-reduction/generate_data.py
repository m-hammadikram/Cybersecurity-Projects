"""
generate_data.py
-----------------
Generates realistic synthetic SOC alert data (SIEM-style) to simulate a busy
enterprise environment producing hundreds of alerts per day, most of which
are false positives / noise. This mimics feeds you'd normally get from
Splunk, ELK, or a Suricata/Zeek sensor.

Run:
    python generate_data.py --days 7 --alerts-per-day 500

Output:
    data/raw_alerts.csv
"""

import argparse
import random
import uuid
from datetime import datetime, timedelta

import pandas as pd

# ---------------------------------------------------------------------------
# Reference data pools
# ---------------------------------------------------------------------------

ALERT_TYPES = [
    ("Failed Login Attempt", "low"),
    ("Brute Force - Multiple Failed Logins", "high"),
    ("Port Scan Detected", "medium"),
    ("Malware Signature Match", "critical"),
    ("Unusual Outbound Traffic Volume", "medium"),
    ("New Device Login", "low"),
    ("Login From Unusual Location", "medium"),
    ("Privilege Escalation Attempt", "high"),
    ("DNS Query to Known Bad Domain", "critical"),
    ("Suspicious PowerShell Execution", "high"),
    ("File Integrity Monitoring Alert", "medium"),
    ("Firewall Rule Violation", "low"),
    ("Antivirus Definition Out of Date", "low"),
    ("Beaconing Behavior Detected", "critical"),
    ("Unusual Process Spawned by Office App", "high"),
    ("USB Device Connected", "low"),
    ("Web Shell Signature Match", "critical"),
    ("Account Lockout", "low"),
    ("Impossible Travel Login", "high"),
    ("SQL Injection Attempt Blocked", "medium"),
]

SEVERITY_WEIGHT = {"low": 1, "medium": 2, "high": 3, "critical": 4}

ASSET_TIERS = {
    # asset_name : criticality (1-5, 5 = crown jewel)
    "DC01-DomainController": 5,
    "FIN-DB-PROD": 5,
    "ERP-APP-SERVER": 4,
    "WEB-PROD-01": 4,
    "HR-FILE-SERVER": 3,
    "DEV-WORKSTATION-14": 1,
    "DEV-WORKSTATION-22": 1,
    "MKT-LAPTOP-07": 1,
    "MKT-LAPTOP-11": 1,
    "SALES-LAPTOP-03": 2,
    "BACKUP-SRV-01": 4,
    "VPN-GATEWAY": 4,
    "PRINT-SRV": 1,
}

USERS = [
    "j.smith", "a.khan", "m.ali", "s.raza", "n.fatima", "svc_backup",
    "svc_monitoring", "admin", "r.patel", "k.chen", "b.hussain", "guest"
]

# A pool of "noisy" source IPs that fire constantly and are almost always
# benign (e.g. vulnerability scanners, load balancers) - used to simulate
# the real-world alert fatigue problem.
CHRONIC_NOISE_IPS = ["10.10.5.21", "10.10.5.22", "10.10.9.4", "172.16.0.50"]

EXTERNAL_IP_POOL = [
    f"203.0.113.{i}" for i in range(2, 40)
] + [f"198.51.100.{i}" for i in range(2, 40)]

INTERNAL_IP_POOL = [f"10.10.{random.randint(0,20)}.{i}" for i in range(2, 254)]


def random_ip(malicious_bias=0.15):
    """Return an IP, occasionally biased toward known chronic-noise IPs."""
    r = random.random()
    if r < 0.10:
        return random.choice(CHRONIC_NOISE_IPS)
    elif r < 0.10 + malicious_bias:
        return random.choice(EXTERNAL_IP_POOL)
    return random.choice(INTERNAL_IP_POOL)


def generate_alerts(days: int, alerts_per_day: int) -> pd.DataFrame:
    """
    Generates a realistic mix of:
      - Background / one-off alerts (~35% of volume): scattered, mostly
        unrelated single events.
      - "Noisy source" bursts (~55% of volume): the same chronic-noise
        source (e.g. a vulnerability scanner) firing many near-identical
        alerts in a tight time window - this is the classic real-world
        cause of alert fatigue, and is exactly what correlation should
        collapse down.
      - Real attack-chain incidents (~10% of volume): a handful of
        multi-stage, cross-alert-type incidents that correlation should
        surface as high-priority.
    """
    records = []
    start_date = datetime.now() - timedelta(days=days)

    for day in range(days):
        day_start = start_date + timedelta(days=day)

        background_count = int(alerts_per_day * 0.35)
        burst_budget = int(alerts_per_day * 0.55)

        # --- Background / scattered alerts -------------------------------
        for _ in range(background_count):
            alert_name, base_sev = random.choice(ALERT_TYPES)
            asset = random.choice(list(ASSET_TIERS.keys()))
            src_ip = random.choice(INTERNAL_IP_POOL + EXTERNAL_IP_POOL)
            user = random.choice(USERS)
            ts = day_start + timedelta(
                hours=random.randint(0, 23),
                minutes=random.randint(0, 59),
                seconds=random.randint(0, 59),
            )
            records.append({
                "alert_id": str(uuid.uuid4())[:8],
                "timestamp": ts,
                "alert_name": alert_name,
                "base_severity": base_sev,
                "src_ip": src_ip,
                "user": user,
                "asset": asset,
                "asset_criticality": ASSET_TIERS[asset],
                "is_chronic_noise_source": False,
            })

        # --- Chronic-noise-source bursts ---------------------------------
        # Same source hammers the environment repeatedly -> correlation
        # engine should collapse each burst into one incident.
        remaining = burst_budget
        while remaining > 0:
            noise_ip = random.choice(CHRONIC_NOISE_IPS)
            noise_user = random.choice(USERS)
            noise_asset = random.choice(list(ASSET_TIERS.keys()))
            burst_size = min(remaining, random.randint(8, 25))
            burst_start = day_start + timedelta(
                hours=random.randint(0, 23), minutes=random.randint(0, 59)
            )
            alert_name, base_sev = random.choice(
                [a for a in ALERT_TYPES if a[1] in ("low", "medium")]
            )
            for i in range(burst_size):
                ts = burst_start + timedelta(seconds=random.randint(0, 600))
                records.append({
                    "alert_id": str(uuid.uuid4())[:8],
                    "timestamp": ts,
                    "alert_name": alert_name,
                    "base_severity": base_sev,
                    "src_ip": noise_ip,
                    "user": noise_user,
                    "asset": noise_asset,
                    "asset_criticality": ASSET_TIERS[noise_asset],
                    "is_chronic_noise_source": True,
                })
            remaining -= burst_size

        # Occasionally inject a "real incident" burst: a cluster of related
        # high-severity alerts from the same source within a short window,
        # simulating an actual attack chain.
        inject_incident = random.random() < 0.6
        incident_ip = random.choice(EXTERNAL_IP_POOL)
        incident_user = random.choice(USERS)
        incident_time = day_start + timedelta(
            hours=random.randint(0, 23), minutes=random.randint(0, 59)
        )

        if inject_incident:
            chain = [
                ("Port Scan Detected", "medium", 0),
                ("Brute Force - Multiple Failed Logins", "high", 4),
                ("Login From Unusual Location", "medium", 6),
                ("Privilege Escalation Attempt", "high", 9),
                ("Beaconing Behavior Detected", "critical", 15),
            ]
            asset = random.choice(list(ASSET_TIERS.keys()))
            for alert_name, sev, offset_min in chain:
                records.append({
                    "alert_id": str(uuid.uuid4())[:8],
                    "timestamp": incident_time + timedelta(minutes=offset_min),
                    "alert_name": alert_name,
                    "base_severity": sev,
                    "src_ip": incident_ip,
                    "user": incident_user,
                    "asset": asset,
                    "asset_criticality": ASSET_TIERS[asset],
                    "is_chronic_noise_source": False,
                })

    df = pd.DataFrame(records).sort_values("timestamp").reset_index(drop=True)
    return df


def main():
    parser = argparse.ArgumentParser(description="Generate synthetic SOC alert data")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--alerts-per-day", type=int, default=400)
    parser.add_argument("--output", type=str, default="data/raw_alerts.csv")
    args = parser.parse_args()

    df = generate_alerts(args.days, args.alerts_per_day)
    df.to_csv(args.output, index=False)
    print(f"Generated {len(df)} alerts across {args.days} days -> {args.output}")


if __name__ == "__main__":
    main()
