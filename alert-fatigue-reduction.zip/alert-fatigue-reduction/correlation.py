"""
correlation.py
---------------
Groups related raw alerts into single "incidents" so an analyst reviews
one correlated incident instead of N separate alerts.

Correlation key: same src_ip AND same user, within a rolling time window.
This mimics real SOAR/SIEM correlation rules (e.g. Splunk's "transaction"
command or Sentinel's fusion alerts).

This is the step that actually reduces alert *volume* seen by the analyst,
while the scoring_engine improves alert *quality* (ranking).
"""

import pandas as pd

CORRELATION_WINDOW_MINUTES = 20


def correlate_alerts(df: pd.DataFrame) -> pd.DataFrame:
    """
    Returns a DataFrame of incidents, where each row represents one or more
    raw alerts grouped together.
    """
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values("timestamp")

    incidents = []
    used = set()

    # Group by (src_ip, user) pairs first - alerts from the same actor
    # against the same account are the strongest correlation signal.
    for (src_ip, user), group in df.groupby(["src_ip", "user"]):
        group = group.sort_values("timestamp").reset_index()
        current_cluster = []

        for i, row in group.iterrows():
            if row["alert_id"] in used:
                continue
            if not current_cluster:
                current_cluster.append(row)
                continue

            last_ts = current_cluster[-1]["timestamp"]
            if (row["timestamp"] - last_ts).total_seconds() <= CORRELATION_WINDOW_MINUTES * 60:
                current_cluster.append(row)
            else:
                incidents.append(_build_incident(current_cluster))
                for r in current_cluster:
                    used.add(r["alert_id"])
                current_cluster = [row]

        if current_cluster:
            incidents.append(_build_incident(current_cluster))
            for r in current_cluster:
                used.add(r["alert_id"])

    incident_df = pd.DataFrame(incidents).sort_values(
        "max_risk_score", ascending=False
    ).reset_index(drop=True)
    return incident_df


def _build_incident(cluster: list) -> dict:
    alert_names = [r["alert_name"] for r in cluster]
    risk_scores = [r["risk_score"] for r in cluster]
    first = cluster[0]
    last = cluster[-1]

    return {
        "incident_id": f"INC-{first['alert_id']}",
        "src_ip": first["src_ip"],
        "user": first["user"],
        "asset": first["asset"],
        "alert_count": len(cluster),
        "alert_types": ", ".join(sorted(set(alert_names))),
        "start_time": first["timestamp"],
        "end_time": last["timestamp"],
        "max_risk_score": max(risk_scores),
        "avg_risk_score": round(sum(risk_scores) / len(risk_scores), 1),
        "highest_priority": max(
            (r["priority"] for r in cluster),
            key=lambda p: ["Info", "Low", "Medium", "High"].index(p)
            if p in ["Info", "Low", "Medium", "High"] else 0,
        ),
        "is_multi_stage": len(set(alert_names)) >= 3,
    }


if __name__ == "__main__":
    scored = pd.read_csv("data/scored_alerts.csv")
    incidents = correlate_alerts(scored)
    incidents.to_csv("data/incidents.csv", index=False)

    print(f"Raw alerts: {len(scored)}")
    print(f"Correlated incidents: {len(incidents)}")
    reduction = 100 * (1 - len(incidents) / len(scored))
    print(f"Alert volume reduction: {reduction:.1f}%")
